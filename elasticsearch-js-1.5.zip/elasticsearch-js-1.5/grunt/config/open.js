module.exports = {
  coverage: {
    path: 'coverage.html',
    app: 'Google Chrome'
  }
};